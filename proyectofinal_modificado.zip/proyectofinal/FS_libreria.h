//libreria_juego_contemos



void impNum(int n1, int n2, ALLEGRO_FONT * Golden_Age_Shad)
{
	ALLEGRO_COLOR azul = al_map_rgb(53, 43, 255);
	al_draw_text(Golden_Age_Shad, azul, 256, 311, NULL, (to_string(n1)).c_str());
	al_draw_text(Golden_Age_Shad, azul, 530, 311, NULL, (to_string(n2)).c_str());
}

int puntaje(int resultado, int avanceJugador, int puntos)
{
	if (avanceJugador == resultado)
	{
		puntos = puntos + 10;
	}
	return puntos;
}

bool respuesta(int resultado, int avanceJugador)
{
	if (avanceJugador == resultado)
	{
		return true; 
	}
	return false;
}



void mensajes(int avanceJugador, int puntos)
{
	al_draw_text(Golden_Age_Shad_pequenio, rojo, 200, 410, NULL, "ESTAS EN EL");
	al_draw_text(Golden_Age_Shad_pequenio, rojo, 480, 410, NULL, "AVANZA");
	al_draw_text(Golden_Age_Shad_pequenio, rojo, 742, 410, NULL, "LlEGASTE A");
	al_draw_text(Golden_Age_Shad, azul, 790, 311, NULL, (to_string(avanceJugador)).c_str());
	al_draw_text(Golden_Age_Shad, rojo, 70, 49, NULL, (to_string(puntos)).c_str());
}

void numCajas(int numFondo, ALLEGRO_FONT* Golden_Age_pequenio)
{
	int i;
	i = 5 * numFondo;
	al_draw_text(Golden_Age_pequenio, negro, 100, 637, NULL, (to_string(i - 4)).c_str());
	al_draw_text(Golden_Age_pequenio, negro, 300, 637, NULL, (to_string(i - 3)).c_str());
	al_draw_text(Golden_Age_pequenio, negro, 500, 637, NULL, (to_string(i - 2)).c_str());
	al_draw_text(Golden_Age_pequenio, negro, 700, 637, NULL, (to_string(i - 1)).c_str());
	al_draw_text(Golden_Age_pequenio, negro, 900, 637, NULL, (to_string(i)).c_str());
}
